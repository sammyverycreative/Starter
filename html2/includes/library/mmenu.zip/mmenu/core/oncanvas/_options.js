const options = {
    hooks: {},
    extensions: [],
    wrappers: [],
    navbar: {
        add: true,
        title: 'Menu',
        titleLink: 'parent'
    },
    onClick: {
        close: null,
        preventDefault: null,
        setSelected: true
    },
    slidingSubmenus: true
};
export default options;
