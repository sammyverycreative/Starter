export default {
    'Menu': 'منو'
};
