export default {
    'Menu': 'Menu'
};
