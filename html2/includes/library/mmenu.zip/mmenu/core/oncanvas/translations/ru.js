export default {
    'Menu': 'Меню'
};
