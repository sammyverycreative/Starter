const configs = {
    scrollOffset: 0,
    updateOffset: 50
};
export default configs;
