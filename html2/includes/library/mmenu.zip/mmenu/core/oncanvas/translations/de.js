export default {
    'Menu': 'Menü'
};
