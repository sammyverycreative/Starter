Source: https://www.github.com/marvinhuebner/slick-animation
E.g.: https://www.codepen.io/alexandrebuffet/pen/zNpmpx